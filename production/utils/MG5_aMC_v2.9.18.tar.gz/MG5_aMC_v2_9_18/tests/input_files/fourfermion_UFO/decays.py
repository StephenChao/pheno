# This file was automatically created by FeynRules 1.7.51
# Mathematica version: 8.0 for Linux x86 (64-bit) (February 23, 2011)
# Date: Thu 2 Aug 2012 10:15:24


from __future__ import absolute_import
from .object_library import all_decays, Decay
from . import particles as P


