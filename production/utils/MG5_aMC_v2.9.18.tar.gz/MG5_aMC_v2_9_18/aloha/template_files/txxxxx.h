#ifndef i_guard
#define i_guard
#include <complex>
void txxxxx(double p[4],double tmass,int nhel,int nst,std::complex<double> fi[18]);
#endif
